create view view1 as
  select `test`.`goods`.`gid`     AS `gid`,
         `test`.`goods`.`gname`   AS `gname`,
         `test`.`goods`.`gprice`  AS `gprice`,
         `test`.`orders`.`oid`    AS `oid`,
         `test`.`orders`.`oprice` AS `oprice`,
         `test`.`orders`.`count`  AS `count`,
         `test`.`orders`.`uid`    AS `uid`,
         `test`.`orders`.`otime`  AS `otime`,
         `test`.`user`.`uname`    AS `uname`,
         `test`.`user`.`tel`      AS `tel`,
         `test`.`user`.`province` AS `province`
  from ((`test`.`goods` join `test`.`orders` on ((`test`.`orders`.`gid` =
                                                  `test`.`goods`.`gid`))) join `test`.`user` on ((`test`.`orders`.`uid`
                                                                                                  =
                                                                                                  `test`.`user`.`uid`)));

